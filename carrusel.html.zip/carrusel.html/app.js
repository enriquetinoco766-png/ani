let imagenes = [
    {
        "url": "img/0.jpg",
        "nombre": "foto 1",
    },
    {
        "url": "img/1.jpg",
        "nombre": "foto 2",
         "descripcion": "amor estos son recuerdos que siempre me van acompañar pero queria hacerte este pequeño regelo amor mio "
    },
    {
        "url": "img/3.jpg",
        "nombre": "foto 3",
         "descripcion": "se que esto no es mucho pero queria hacerte algo amor mio"
    },
        {
        "url": "img/4.jpg",
        "nombre": "foto 4",
         "descripcion": "yo te dije que siempre iba a estar para ti amor mio "
    },
        {
        "url": "img/9.jpg",
        "nombre": "foto 5",
         "descripcion": "se me ocurrio hacerte estos dos pequeños detalles amor mio"
    },
        {
        "url": "img/6.jpg",
        "nombre": "foto 6",
         "descripcion": "te amor mucho mi princesa me estas amor enserio y siempre quiero estar contigo amor"
    },
        {
        "url": "img/7.jpg",
        "nombre": "foto 7",
            "descripcion": "amor espero que tengamos 2 años tu y yo siempre juntos amor mio "
    },
        {
        "url": "img/8.jpg",
        "nombre": "foto 8",
        "descripcion": "Esto es un pequeño regalo amor mio te amo mucho mi vida hermosa eres lo mas importante que tengo te amo"

    },
]


let atras = document.getElementById('atras');
let adelante = document.getElementById('adelante');
let imagen = document.getElementById('img');
let puntos = document.getElementById('puntos');
let texto = document.getElementById('texto')
let actual = 0
posicionCarrusel()

atras.addEventListener('click', function(){
    actual -=1

    if (actual == -1){
        actual = imagenes.length - 1
    }

    imagen.innerHTML = ` <img class="img" src="${imagenes[actual].url}" alt="logo pagina" loading="lazy"></img>`
    texto.innerHTML = `
    <h3>${imagenes[actual].nombre}</h3>
    <p>${imagenes[actual].descripcion}</p>
    `
    posicionCarrusel()
})  
adelante.addEventListener('click', function(){
    actual +=1

    if (actual == imagenes.length){
        actual = 0
    }

    imagen.innerHTML = ` <img class="img" src="${imagenes[actual].url}" alt="logo pagina" loading="lazy"></img>`
    texto.innerHTML = `
    <h3>${imagenes[actual].nombre}</h3>
    <p>${imagenes[actual].descripcion}</p>
    `
    posicionCarrusel()
})  

function posicionCarrusel() {
    puntos.innerHTML = ""
    for (var i = 0; i <imagenes.length; i++){
        if(i == actual){
            puntos.innerHTML += '<p class="bold">.<p>'
        }
        else{
            puntos.innerHTML += '<p>.<p>'
        }
    } 
}
